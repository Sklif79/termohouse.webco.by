<?php

include_once dirname(__FILE__) . '/../ru/frontend.inc.php';