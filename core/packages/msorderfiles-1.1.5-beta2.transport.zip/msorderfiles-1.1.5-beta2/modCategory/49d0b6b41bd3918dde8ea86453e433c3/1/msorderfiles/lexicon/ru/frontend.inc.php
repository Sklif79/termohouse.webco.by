<?php

// Сообщения
$_lang['msorderfiles_frontend_message'] = 'Переместите файлы или нажмите, чтобы загрузить';

// Dropzone
$_lang['msorderfiles_dz_dictMaxFilesExceeded'] = 'Вы не можете загрузить больше файлов.';
$_lang['msorderfiles_dz_dictFallbackMessage'] = 'Ваш браузер не поддерживает загрузку файлов перетаскиванием.';
$_lang['msorderfiles_dz_dictFileTooBig'] = 'Файл слишком большой ({{filesize}}MB). Максимальный размер: {{maxFilesize}}MB';
$_lang['msorderfiles_dz_dictInvalidFileType'] = 'Вы не можете загружать файлы этого типа';
$_lang['msorderfiles_dz_dictResponseError'] = 'Ошибка ответа, код: {{statusCode}}';
$_lang['msorderfiles_dz_dictCancelUpload'] = 'Отмена загрузки';
$_lang['msorderfiles_dz_dictCancelUploadConfirmation'] = 'Вы уверены, что хотите отменить эту загрузку?';
$_lang['msorderfiles_dz_dictRemoveFile'] = 'Удалить файл';
$_lang['msorderfiles_dz_dictDefaultCanceled'] = 'Загрузка отменена';