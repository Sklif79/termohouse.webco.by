<?php
class msLink extends xPDOSimpleObject {}