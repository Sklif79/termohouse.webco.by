<?php
require_once (dirname(dirname(__FILE__)) . '/msproductoption.class.php');
class msProductOption_mysql extends msProductOption {}