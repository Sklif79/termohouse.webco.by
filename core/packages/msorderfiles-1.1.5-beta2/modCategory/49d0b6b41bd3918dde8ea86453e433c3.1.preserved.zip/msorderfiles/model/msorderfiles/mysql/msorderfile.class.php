<?php
require_once (dirname(__DIR__) . '/msorderfile.class.php');
class msOrderFile_mysql extends msOrderFile {}