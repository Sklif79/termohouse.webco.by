--------------------
msOrderFiles
--------------------
Author: Pavel Gvozdb <pavelgvozdb@yandex.ru>
--------------------

A basic Extra for MODx Revolution.

Feel free to suggest ideas/improvements/bugs on GitHub:
http://github.com/username/msOrderFiles/issues