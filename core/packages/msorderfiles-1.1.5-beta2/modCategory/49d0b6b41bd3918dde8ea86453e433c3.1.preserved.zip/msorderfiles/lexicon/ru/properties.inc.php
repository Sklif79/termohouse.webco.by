<?php

$_lang['msorderfiles_prop_limit'] = 'Ограничение вывода Предметов на странице.';
$_lang['msorderfiles_prop_outputSeparator'] = 'Разделитель вывода строк.';
$_lang['msorderfiles_prop_sortBy'] = 'Поле сортировки.';
$_lang['msorderfiles_prop_sortDir'] = 'Направление сортировки.';
$_lang['msorderfiles_prop_tpl'] = 'Чанк оформления каждого ряда Предметов.';
$_lang['msorderfiles_prop_toPlaceholder'] = 'Усли указан этот параметр, то результат будет сохранен в плейсхолдер, вместо прямого вывода на странице.';
