<?php
include_once 'setting.inc.php';

$_lang['msto'] = 'msTradeOffers';
$_lang['msto_menu_desc'] = 'Дополнительные цены - настройки.';

$_lang['msto_settings'] = 'Настройки';

$_lang['msto_setting_option'] = 'Опции';
$_lang['msto_setting_option_intro'] = 'Панель управления опциями продукта.';

$_lang['msto_setting_operation'] = 'Операции';
$_lang['msto_setting_operation_intro'] = 'Панель управления операциями над ценами.';