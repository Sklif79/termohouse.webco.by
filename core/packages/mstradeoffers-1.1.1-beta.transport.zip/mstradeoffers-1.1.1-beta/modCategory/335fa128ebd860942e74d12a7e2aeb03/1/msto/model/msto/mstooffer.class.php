<?php
class mstoOffer extends xPDOSimpleObject {}