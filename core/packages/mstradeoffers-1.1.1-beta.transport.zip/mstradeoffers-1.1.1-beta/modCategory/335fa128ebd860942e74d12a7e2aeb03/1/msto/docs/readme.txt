--------------------
msTradeOffers
--------------------
Author: Vgrish <vgrish@gmail.com>
--------------------

A basic Extra for MODx Revolution.