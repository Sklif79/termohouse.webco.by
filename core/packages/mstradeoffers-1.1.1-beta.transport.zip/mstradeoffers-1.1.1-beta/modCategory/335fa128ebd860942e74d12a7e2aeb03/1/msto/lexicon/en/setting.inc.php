<?php

$_lang['area_msto_main'] = 'Main';

$_lang['setting_msto_active'] = 'Active / Inactive';

$_lang['setting_msto_allow_zero_price'] = 'Allow zero price';

$_lang['setting_msto_frontend_js'] = 'Frontend javascript';

$_lang['setting_msto_frontend_css'] = 'Frontend css';
