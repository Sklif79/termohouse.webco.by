<?php
require_once (dirname(dirname(__FILE__)) . '/mstooffer.class.php');
class mstoOffer_mysql extends mstoOffer {}