<?php
class mstoOfferFile extends xPDOSimpleObject {}