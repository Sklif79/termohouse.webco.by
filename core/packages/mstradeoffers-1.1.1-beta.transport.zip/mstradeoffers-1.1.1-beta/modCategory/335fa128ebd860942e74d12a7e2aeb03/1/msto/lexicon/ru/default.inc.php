<?php
include_once 'setting.inc.php';

$_lang['msto'] = 'msTradeOffers';
$_lang['msto_settings'] = 'Настройки';


