<?php
require_once (dirname(dirname(__FILE__)) . '/mstoofferfile.class.php');
class mstoOfferFile_mysql extends mstoOfferFile {}