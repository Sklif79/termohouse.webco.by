<?php
/**
 * migx
 *
 * @package migx
 * @language cs
 *
 * @author modx.cz
 */


$_lang['mig.tabs'] = 'Taby formuláře';
$_lang['mig.columns'] = 'Sloupce tabulky';
$_lang['mig.btntext'] = '"Přidat položku" Nahrazení';
$_lang['mig.previewurl'] = 'Náhled Url';
$_lang['mig.jsonvarkey'] = 'Náhled JsonVarKey';
$_lang['mig.configs'] = 'Konfigurace';
$_lang['mig.autoResourceFolders'] = 'Automaticky vytvořit složku pro každý dokument';