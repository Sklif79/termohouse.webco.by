<?php
require_once (dirname(__DIR__) . '/msdusergroup.class.php');
class msdUserGroup_mysql extends msdUserGroup {}