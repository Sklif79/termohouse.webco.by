<?php
class msdSaleMember extends xPDOObject {}