<?php

$_lang['msdiscount_save'] = 'Разрешает создание или изменение акций и скидок miniShop2';
$_lang['msdiscount_view'] = 'Разрешает просматривать свойства акций и скидок miniShop2';