<?php

$_lang['msdiscount_prop_id'] = 'An id of product';
$_lang['msdiscount_prop_sale'] = 'Comma-separated list of sales to output.';
$_lang['msdiscount_prop_tpl'] = 'Chunk for output result of snippets work.';
$_lang['msdiscount_prop_frontend_css'] = 'A css file for the frontend.';
$_lang['msdiscount_prop_frontend_js'] = 'A javascript file for the frontend.';
$_lang['msdiscount_prop_force_date'] = 'Select only products with time limited sales.';