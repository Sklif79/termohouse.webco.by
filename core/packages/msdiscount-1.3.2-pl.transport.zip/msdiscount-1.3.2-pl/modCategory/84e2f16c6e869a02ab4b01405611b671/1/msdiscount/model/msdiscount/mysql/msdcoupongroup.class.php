<?php
require_once (dirname(__DIR__) . '/msdcoupongroup.class.php');
class msdCouponGroup_mysql extends msdCouponGroup {}