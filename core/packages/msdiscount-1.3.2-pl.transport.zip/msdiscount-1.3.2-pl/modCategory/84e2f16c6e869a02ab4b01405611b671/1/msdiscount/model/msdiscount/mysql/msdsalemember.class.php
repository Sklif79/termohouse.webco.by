<?php
require_once (dirname(__DIR__) . '/msdsalemember.class.php');
class msdSaleMember_mysql extends msdSaleMember {}