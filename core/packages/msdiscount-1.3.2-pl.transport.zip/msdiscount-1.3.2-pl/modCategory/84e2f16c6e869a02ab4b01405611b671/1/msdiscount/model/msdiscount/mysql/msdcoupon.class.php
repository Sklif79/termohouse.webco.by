<?php
require_once (dirname(__DIR__) . '/msdcoupon.class.php');
class msdCoupon_mysql extends msdCoupon {}