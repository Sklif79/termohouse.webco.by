<?php
class msdUserGroup extends xPDOSimpleObject {}