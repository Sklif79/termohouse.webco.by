<?php

$_lang['area_msd_main'] = 'Main';

$_lang['setting_msd_price_round'] = 'Round prices';
$_lang['setting_msd_price_round_desc'] = 'If you enable this setting all prices of discount products will be rounded to integers';
$_lang['setting_msd_coupon_only_products'] = 'Coupon only for products';
$_lang['setting_msd_coupon_only_products_desc'] = 'By default discount of a coupon applies only for a products, not for a whole cart with shipping. You can change this behaviour.';