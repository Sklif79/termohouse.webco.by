<?php
require_once (dirname(__DIR__) . '/msdproductgroup.class.php');
class msdProductGroup_mysql extends msdProductGroup {}