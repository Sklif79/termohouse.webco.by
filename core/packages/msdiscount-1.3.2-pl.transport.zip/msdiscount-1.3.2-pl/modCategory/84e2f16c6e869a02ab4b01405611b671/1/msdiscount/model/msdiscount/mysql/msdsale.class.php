<?php
require_once (dirname(__DIR__) . '/msdsale.class.php');
class msdSale_mysql extends msdSale {}