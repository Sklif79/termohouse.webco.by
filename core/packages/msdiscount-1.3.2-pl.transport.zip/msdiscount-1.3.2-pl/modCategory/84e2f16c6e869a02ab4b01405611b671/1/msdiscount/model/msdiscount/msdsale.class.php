<?php
class msdSale extends xPDOSimpleObject {}