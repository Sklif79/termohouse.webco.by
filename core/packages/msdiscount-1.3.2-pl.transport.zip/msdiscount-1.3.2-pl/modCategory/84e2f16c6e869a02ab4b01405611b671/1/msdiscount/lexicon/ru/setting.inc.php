<?php

$_lang['area_msd_main'] = 'Основные';

$_lang['setting_msd_price_round'] = 'Округлять цены';
$_lang['setting_msd_price_round_desc'] = 'При включении этой настройки все цены на товары со скидкой будут округляться до целых.';
$_lang['setting_msd_coupon_only_products'] = 'Купон только для товаров';
$_lang['setting_msd_coupon_only_products_desc'] = 'По умолчанию скидка купона применяется только к товарам, а не ко всей корзине вместе с доставкой. Вы можете переопределить это поведение.';