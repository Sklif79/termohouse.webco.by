--------------------
msOptionsPrice
--------------------
Author: Vgrish <vgrish@gmail.com>
--------------------