<?php
require_once (dirname(__DIR__) . '/msopmodification.class.php');
class msopModification_mysql extends msopModification {}