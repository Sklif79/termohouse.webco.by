<?php
$ns = 'updater.';

$_lang[$ns.'perm.system_perform_maintenance_tasks']       = 'General permission for system maintenance related tasks.';
$_lang[$ns.'perm.system_receive_core_notifications']      = 'Allow user to receive core notifications.';
$_lang[$ns.'perm.system_receive_package_notifications']   = 'Allow user to receive package notifications.';
