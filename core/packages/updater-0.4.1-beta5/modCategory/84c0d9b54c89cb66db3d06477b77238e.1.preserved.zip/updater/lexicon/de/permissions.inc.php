<?php
$ns = 'updater.';

$_lang[$ns.'perm.system_perform_maintenance_tasks']       = 'Allgemeine Erlaubnis, systemadministrative Aufgaben durchzuführen.';
$_lang[$ns.'perm.system_receive_core_notifications']      = 'Erlaube Benutzer, Core-Benachrichtigungen zu erhalten.';
$_lang[$ns.'perm.system_receive_package_notifications']   = 'Erlaube Benutzer, Package-Benachrichtigungen zu erhalten.';
